# Biometric-Attendance-system-V2.0




If you find my work helpful, it would be kind to have a cup of coffee from you,


<a href="https://www.buymeacoffee.com/1rp8CJx" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-green.png" alt="Buy Me A Coffee" height="60" width="217" ></a>
